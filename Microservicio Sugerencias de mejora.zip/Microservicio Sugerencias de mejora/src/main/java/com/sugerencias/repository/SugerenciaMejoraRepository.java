package com.sugerencias.repository;

import com.sugerencias.model.SugerenciaMejora;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SugerenciaMejoraRepository extends JpaRepository<SugerenciaMejora, Integer> {
}
