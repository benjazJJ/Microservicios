package com.sugerencias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SugerenciaApplication {
    public static void main(String[] args) {
        SpringApplication.run(SugerenciaApplication.class, args);
    }
}
