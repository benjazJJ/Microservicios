package Servicio.Sugerencias.de.mejora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SugerenciasDeMejoraApplicationTests {

	@Test
	void contextLoads() {
	}

}
